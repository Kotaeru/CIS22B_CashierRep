// Function prototype
void cashier();
