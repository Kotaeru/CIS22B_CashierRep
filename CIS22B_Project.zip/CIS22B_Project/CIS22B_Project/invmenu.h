// Fucntion prototypes
void lookUpBook();
void addBook();
void editBook();
void deleteBook();
void invMenu();
void bookInfo(char isbn[], char title[], char author[], 
			  char publisher[], char date[], int qty,
			  double wholeSale, double retail);
