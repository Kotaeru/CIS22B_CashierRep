void cashier();
void invMenu();
void reports();
