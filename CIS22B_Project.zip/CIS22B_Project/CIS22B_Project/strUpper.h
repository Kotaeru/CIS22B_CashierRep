void strUpper(char*);
